import javax.swing.JLabel;

public class Consumidor extends Thread {
  
  private JLabel navio;
  private Mapa mapa;

  // velocidades 
  // velocidade 0 = while
  // velocidade 1 = 50s
  // velocidade 2 = 40s
  // velocidade 3 = 30s
  // velocidade 4 = 25s
  // velocidade 5 = 20s
  private int velocidade =1;

  private int cont =1;

  public Consumidor(JLabel navio, Mapa mapa){
    this.navio = navio;
    this.mapa = mapa;
  }

  public void run() {
    while(true){
      if(getVelocidade()==1){
        while(getVelocidade()==1){
          sleepi(1);
        }
      }else{
        try {
          ida();
        } catch (InterruptedException e) {
          e.printStackTrace();
        }
        sleepi(getVelocidade());

        volta();
      }
    }
  }

  public void consumirItem(){
    for(int i=0; i<Controlador.buffer.length;i++){
      if(Controlador.getBuffer(i)!=0){
        Controlador.setBuffer(i, 0);
        mapa.BarrilVisivel("retirar", i);
        break;
      }
    }
  }

  public void ida() throws InterruptedException{
    if(cont ==1){
      if(navio.getX() >=464){
        navio.setLocation(navio.getX()-2, navio.getY());
      }
      if(navio.getX()==464){

        Controlador.full.acquire();
        Controlador.mutex.acquire();

        consumirItem();

        Controlador.mutex.release();
        Controlador.empty.release();

        cont =0;
        mapa.AlterarDirecao("volta", "R2", this.navio);
      }
    }
  }

  public void volta(){
    if(cont ==0){
      if(navio.getX()<=592){
        navio.setLocation(navio.getX()+2, navio.getY());
      }
      if(navio.getX()==592){
        cont=1;
        mapa.AlterarDirecao("ida", "R2", this.navio);
      }
    }
  }

  public void sleepi(int valor){
    try {
      sleep(valor);
    } catch (InterruptedException e) { // fim do try
      e.printStackTrace();
    }
  }

  public int getVelocidade() {
    return velocidade;
  }

  public void setVelocidade(int velocidade) {
    this.velocidade = velocidade;
  }
}

