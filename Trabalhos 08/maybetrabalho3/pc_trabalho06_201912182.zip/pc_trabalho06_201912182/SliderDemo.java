import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class SliderDemo implements ChangeListener{

  private JSlider slider;
  private Produtor produtor;
  private Consumidor consumidor;
  private String tipo;
  private int VELOCIDADE_INIT = 0;
  static final int VELOCIDADE_MIN = 0;
  static final int VELOCIDADE_MAX = 5;

  public SliderDemo(Produtor produtor, Consumidor consumidor, String tipo){

    this.produtor = produtor;
    this.consumidor = consumidor;
    this.tipo = tipo;

    slider = new JSlider(JSlider.HORIZONTAL,
    VELOCIDADE_MIN, VELOCIDADE_MAX, VELOCIDADE_INIT);
    slider.setSize(20, 20);

    slider.setPaintTicks(true);
    slider.setMajorTickSpacing(1);
    
    slider.setPaintLabels(true);

    slider.addChangeListener(this);
  }

  public void setLocationSlider(int x, int y){
    slider.setLocation(x, y);
  }

  public JSlider getSlider() {
    return slider;
  }

  public void setSize(int largura, int altura){
    slider.setSize(largura,altura);
  }

  public void setSlider(JSlider slider) {
    this.slider = slider;
  }
  
  public Produtor getProdutor() {
    return produtor;
  }

  public void setProdutor(Produtor produtor) {
    this.produtor = produtor;
  }

  public Consumidor getConsumidor() {
    return consumidor;
  }

  public void setConsumidor(Consumidor consumidor) {
    this.consumidor = consumidor;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public void setSliderVisible(boolean valor){
    slider.setVisible(valor);
  }

  public int getVELOCIDADE_INIT() {
    return VELOCIDADE_INIT;
  }

  public void setVELOCIDADE_INIT(int vELOCIDADE_INIT) {
    VELOCIDADE_INIT = vELOCIDADE_INIT;
  }

  // velocidades 
  // velocidade 0 = while
  // velocidade 1 = 50s
  // velocidade 2 = 40s
  // velocidade 3 = 30s
  // velocidade 4 = 25s
  // velocidade 5 = 20s
  @Override
  public void stateChanged(ChangeEvent e) {

    if(getTipo()=="produtor"){
      if(slider.getValue()==0){
        produtor.setVelocidade(1);
      }
      if(slider.getValue()==1){
        produtor.setVelocidade(50);
      }
      if(slider.getValue()==2){
        produtor.setVelocidade(40);
      }
      if(slider.getValue()==3){
        produtor.setVelocidade(30);
      }
      if(slider.getValue()==4){
        produtor.setVelocidade(25);
      }
      if(slider.getValue()==5){
        produtor.setVelocidade(20);
      }
    }else if(getTipo()=="consumidor"){
      if(slider.getValue()==0){
        consumidor.setVelocidade(1);
      }
      if(slider.getValue()==1){
        consumidor.setVelocidade(50);
       
      }
      if(slider.getValue()==2){
        consumidor.setVelocidade(40);
        
      }
      if(slider.getValue()==3){
        consumidor.setVelocidade(30);
        
      }
      if(slider.getValue()==4){
        consumidor.setVelocidade(25);
        
      }
      if(slider.getValue()==5){
        consumidor.setVelocidade(20);
      
      }
    }
  }
}
