import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JPanel;

public class ImagePanel extends JPanel{

    private BufferedImage image;

    public ImagePanel() {
       try {                
        image = ImageIO.read(this.getClass().getResource("mapa2_grande.png"));
       } catch (IOException ex) {
            // handle exception...
       }
       gerarPanel();
    }

    public void gerarPanel(){
      this.setBackground(new Color(0,0,0)); 
      this.setSize(800,553);                        
      this.setLayout(null);
    } 

    public void addPanel(JComponent comp){
      this.add(comp);
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, 0, 0, this); // see javadoc for more info on the parameters            
    }

}