
import javax.swing.JLabel;

public class Produtor extends Thread {
  
  private Controlador controlador;
  private JLabel navio;
  private Mapa mapa;
  private int barril;

  private boolean estado =false;

  private int velocidade =1;

  private int cont =1;
  private int cont2 =1;

  public Produtor(JLabel navio, Mapa mapa,Controlador controlador){
    this.navio = navio;
    this.mapa = mapa;
    this.controlador = controlador;
  }

  public void run() {
    while(true){
      if(getVelocidade()==1){
        while(getVelocidade()==1 && estado == false){
          sleepi(1);
        }
      }else{

        produzirItem();
      
        try {
          ida();
        } catch (InterruptedException e) {
          e.printStackTrace();
        }

        volta();

        sleepi(getVelocidade());
      }
    }
  }

  public void produzirItem(){
    if(cont2 ==1){
      barril = controlador.ProduzirBarril();
      cont2 =0;
    }
  }

  public void inserirItem(){
    for(int i=0; i<Controlador.buffer.length;i++){
      if(Controlador.getBuffer(i)==0){
        Controlador.setBuffer(i, barril);
        mapa.BarrilVisivel("inserir", i);
        break;
      }
    }
  }

  public void ida() throws InterruptedException{
    if(cont ==1){
      if(navio.getX() <=240){
        navio.setLocation(navio.getX()+2, navio.getY());
      }
      if(navio.getX()==240){

        Controlador.empty.acquire(); 
        Controlador.mutex.acquire(); 

        inserirItem();

        Controlador.mutex.release();
        Controlador.full.release();

        cont =0;
        mapa.AlterarDirecao("volta", "R1", this.navio);
      }
    }
  }

  public void volta(){
    if(cont ==0){
      if(navio.getX()>=110){
        navio.setLocation(navio.getX()-2, navio.getY());
      }
      if(navio.getX()<=110){
        cont=1;
        mapa.AlterarDirecao("ida", "R1", this.navio);
        cont2 =1;
      }
    }
  }

  public void sleepi(int valor){
    try {
      sleep(valor);
    } catch (InterruptedException e) { // fim do try
      e.printStackTrace();
    }
  }
    
  public int getVelocidade() {
    return velocidade;
  }

  public void setVelocidade(int velocidade) {
    this.velocidade = velocidade;
  }

  public boolean isEstado() {
    return estado;
  }

  public void setEstado(boolean estado) {
    this.estado = estado;
  }
}
