import java.util.concurrent.Semaphore;
import java.util.Random;

public class Controlador {

  private Random rand = new Random(1000L);

  public static int[] buffer = new int[7];  
  public static Semaphore mutex = new Semaphore(1); // Mutua exclusao
  public static Semaphore empty = new Semaphore(buffer.length); // Conta os espacos vazios
  public static Semaphore full = new Semaphore(0); // Conta os espacos ocupados

  public Controlador(){
    esvaziarBuffer();
  }
  
  public int ProduzirBarril(){
    int barril = rand.nextInt(6) +1;
    return barril;
  }

  public void esvaziarBuffer(){
    for(int i=0; i<buffer.length;i++){
      buffer[i] =0;
    }
  }

  public static void setBuffer(int posicao,int valor) {
    for(int i=0; i<buffer.length;i++){
      if(i==posicao){
        buffer[i] = valor;
      } // fim do if
    } // fim do for
  } 

  public static int getBuffer(int posicao) {
    int valor =0;
    for(int i=0; i<buffer.length;i++){
      if(i==posicao){
        valor = buffer[i];
      } // fim do if
    } // fim do for
    return valor;
  } // fim do metodo

  public static void ImprimirVetor(){
    for(int i = 0 ; i < buffer.length ; i++)
          System.out.print("[" + i + "] " + buffer[i] + " ");
          System.out.println(" ");
  }
}
