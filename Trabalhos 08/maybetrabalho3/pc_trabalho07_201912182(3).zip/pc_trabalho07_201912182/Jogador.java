public class Jogador extends Thread{
  private int index;
  private Jogador jogadorEsquerda;
  private Jogador jogadorDireita;
  private int velocidadePensar = (1000 + (int)(Math.random() * 1000));
  private int velocidadeJogar = (1000 + (int)(Math.random() * 1000));

  public Jogador(int index){
    this.index = index;
  }

  public void run(){
    while(true){
        try {
          pensar();
          pegarControles();
          jogar();
          devolverControles();
        } catch (InterruptedException e) {
          e.printStackTrace();
        }
    }
  }

  public void setVizinhaca(){
    this.jogadorDireita = Controlador.jogadores[(getIndex() + 1 + 5)%5];
    this.jogadorEsquerda = Controlador.jogadores[(getIndex() - 1 +5)%5];
  } // fim do metodo setVizinhanca

  public void pensar() throws InterruptedException {
    Thread.sleep(velocidadePensar);
  } //fim do metodo pensar

  public void jogar() throws InterruptedException {
    Controlador.mapinha.alterarVisibilidadeControles(this.getIndex(),"false");
    Controlador.mapinha.alterarVisibilidadeControles(this.jogadorEsquerda.getIndex(),"false");
    Controlador.mapinha.alterarControleCompleto(this.getIndex(),"true");
    Thread.sleep(velocidadeJogar);
  } // fim do metodo jogar

  public void pegarControles() throws InterruptedException{
    Controlador.mutex.acquire();
    Controlador.estados[getIndex()] =1;
    Jogador.verificar(this);
    Controlador.mutex.release();
    Controlador.controles[getIndex()].acquire(); 
  } // fim do metodo pegarControles

  public void devolverControles() throws InterruptedException{
    Controlador.mutex.acquire();
    Controlador.estados[getIndex()] = 0;
    Controlador.mapinha.alterarVisibilidadeControles(this.getIndex(),"true");
    Controlador.mapinha.alterarVisibilidadeControles(this.jogadorEsquerda.getIndex(),"true");
    Controlador.mapinha.alterarControleCompleto(this.getIndex(),"false");
    Jogador.verificar(jogadorEsquerda);
    Jogador.verificar(jogadorDireita);
    Controlador.mutex.release();
  }

  public static void verificar(Jogador player) throws InterruptedException{
    if(Controlador.estados[player.getIndex()] == 1 && 
        Controlador.estados[player.getJogadorEsquerda().getIndex()] != 2 && 
        Controlador.estados[player.getJogadorDireita().getIndex()] != 2) {
         Controlador.estados[player.getIndex()] = 2;
         Controlador.controles[player.getIndex()].release();
    }
  }

  public int getIndex() {
    return index;
  }

  public void setIndex(int index) {
    this.index = index;
  }

  public Jogador getJogadorEsquerda() {
    return jogadorEsquerda;
  }

  public void setJogadorEsquerda(Jogador jogadorEsquerda) {
    this.jogadorEsquerda = jogadorEsquerda;
  }

  public Jogador getJogadorDireita() {
    return jogadorDireita;
  }

  public void setJogadorDireita(Jogador jogadorDireita) {
    this.jogadorDireita = jogadorDireita;
  }

  public int getVelocidadePensar() {
    return velocidadePensar;
  }

  public void setVelocidadePensar(int velocidadePensar) {
    this.velocidadePensar = velocidadePensar;
  }

  public int getVelocidadeJogar() {
    return velocidadeJogar;
  }

  public void setVelocidadeJogar(int velocidadeJogar) {
    this.velocidadeJogar = velocidadeJogar;
  }
}
