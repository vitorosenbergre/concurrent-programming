/* ***************************************************************
* Autor: Vitor Rosenbergre dos Santos Carmo
* Matricula: 201912182
* Inicio: 20/05/2021
* Ultima alteracao: 23/05/2021
* Nome do Programa: Producao e consumo de barris de petroleo.
* Classe: Principal
* Funcao: Simula a introducao de itens no buffer que utilizam dos semaforos, por meio de navios produtores 
* e navios consumidores de barris de petroleo.
*************************************************************** */

import java.io.IOException;

public class Principal {
  public static void main(String[] args) throws IOException {
    new Controlador();
    //new Mapa();
  } // fim da main
} // fim da class Principal