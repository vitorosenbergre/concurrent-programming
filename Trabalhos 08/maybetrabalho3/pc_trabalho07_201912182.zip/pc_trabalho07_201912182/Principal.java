/* ***************************************************************
* Autor: Vitor Rosenbergre dos Santos Carmo.
* Matricula: 201912182.
* Inicio: 03/06/2021.
* Ultima alteracao: 05/06/2021.
* Nome do Programa: Mesa dos Gamers.
* Classe: Principal.
* Funcao: Simular 5 jogadores de nitendo switch dividindo 5 controles, para que eles possam jogar.
* Os jogadores podem descansar, querer jogar, e jogar. 
* Para se jogar, eh necessario ter dois controles do nitendo, esperando quando os controles proximos 
* nao estiverem disponiveis. 
*************************************************************** */

public class Principal {
  public static void main(String[] args){
    new Controlador();
  } // fim da main
} // fim da class Principal