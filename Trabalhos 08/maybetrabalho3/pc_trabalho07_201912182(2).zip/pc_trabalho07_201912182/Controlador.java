import java.util.concurrent.Semaphore;

public class Controlador{
  // vetor com os Jogadores
  public static Jogador[] jogadores = new Jogador[5];
  // vetor com o estado de cada jogador, o index representando cada jogador
  public static int[] estados = new int[5];
  // vetor representando os controles, se pode pegar ou n;
  public static Semaphore[] controles = new Semaphore[5];
  // mutex
  public static Semaphore mutex = new Semaphore(1);

  public static Mapa mapinha = new Mapa();
  
  public Controlador(){
    for(int i = 0 ; i < 5 ; i++){
      //deixar eles pensando e iniciando o "garfos" com 0;
      controles[i] = new Semaphore(0);
      estados[i] = 0;
      
      // acrescenta os jogadores no vetor, para fazer o manuseio
      jogadores[i] = new Jogador(i);

      // setando sliders
      mapinha.setarJogador(jogadores[i], i);
    }//fim do for
    
    for(int i = 0 ; i < 5; i++){
      jogadores[i].setVizinhaca();
      jogadores[i].start();
    }//fim do for
  }
}
