/* ***************************************************************
* Autor: Vitor Rosenbergre dos Santos Carmo
* Matricula: 201912182
* Inicio: 20/05/2021
* Ultima alteracao: 23/05/2021
* Nome do Programa: Producao e consumo de barris de petroleo.
* Classe: SliderDemo
* Funcao: Controlar a velocidade dos navios produtores e consumidores.
*************************************************************** */

import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class SliderDemo implements ChangeListener{

  //variavel do Jslider
  private JSlider slider;

  // jogador que vai ter a variavel alterada
  private Jogador jogador;

  // tipo de slider
  private String tipo;

  // constante representando a velocidade inicial do slider
  private int VELOCIDADE_INIT = 0;
  
  // constante representando a velocidade minima do slider
  static final int VELOCIDADE_MIN = 0;
  
  // constante representando a velocidade maxima do slider
  static final int VELOCIDADE_MAX = 5;

  public SliderDemo(Jogador jogador, String tipo){

    this.jogador = jogador;
    this.tipo = tipo;
    
    slider = new JSlider(JSlider.HORIZONTAL,
    VELOCIDADE_MIN, VELOCIDADE_MAX, VELOCIDADE_INIT);
    slider.setSize(20, 20);

    slider.setPaintTicks(true);
    slider.setMajorTickSpacing(1);
    
    slider.setPaintLabels(true);

    slider.addChangeListener(this);
  } // fim do construtor SliderDemo

  /* ***************************************************************
  * Metodo: setLocationSlider.
  * Funcao: altera a localizacao do slider no panel.
  * Parametros: int x, int y.
  * Retorno: nenhum.
  *************************************************************** */
  public void setLocationSlider(int x, int y){
    slider.setLocation(x, y);
  } // fim do metodo setLocationSlider

  /* ***************************************************************
  * Metodo: getSlider.
  * Funcao: retorna a variavel slider.
  * Parametros: nenhum.
  * Retorno: JSlider slider.
  *************************************************************** */
  public JSlider getSlider() {
    return slider;
  } // fim do metodo getSlider

  /* ***************************************************************
  * Metodo: setSize.
  * Funcao: altera o tamanho do slider no panel.
  * Parametros: int largura, int altura.
  * Retorno: nenhum.
  *************************************************************** */
  public void setSize(int largura, int altura){
    slider.setSize(largura,altura);
  } // fim do metodo setSize

  /* ***************************************************************
  * Metodo: setSlider.
  * Funcao: troca de JSlider.
  * Parametros: JSlider slider.
  * Retorno: nenhum.
  *************************************************************** */
  public void setSlider(JSlider slider) {
    this.slider = slider;
  } // fim do metodo setSlider

  /* ***************************************************************
  * Metodo: setSliderVisible.
  * Funcao: troca a visibilizade do slider.
  * Parametros: boolean valor.
  * Retorno: nenhum.
  *************************************************************** */
  public void setSliderVisible(boolean valor){
    slider.setVisible(valor);
  } // fim do metodo setSliderVisible

  /* ***************************************************************
  * Metodo: getVELOCIDADE_INIT().
  * Funcao: retorna a variavel VELOCIDADE_INIT.
  * Parametros: nenhum.
  * Retorno: int VELOCIDADE_INIT.
  *************************************************************** */
  public int getVELOCIDADE_INIT() {
    return VELOCIDADE_INIT;
  } // fim do metodo getVELOCIDADE_INIT
  
  /* ***************************************************************
  * Metodo: setVELOCIDADE_INIT.
  * Funcao: troca o valor inicial do slider.
  * Parametros: int vELOCIDADE_INIT.
  * Retorno: nenhum.
  *************************************************************** */
  public void setVELOCIDADE_INIT(int vELOCIDADE_INIT) {
    VELOCIDADE_INIT = vELOCIDADE_INIT;
  } // fim do metodo setVELOCIDADE_INIT

  
  public Jogador getJogador() {
    return jogador;
  }

  public void setJogador(Jogador jogador) {
    this.jogador = jogador;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }
  // velocidades
  // velocidade 0 =  1
  // velocidade 1 = 7000
  // velocidade 2 = 5000
  // velocidade 3 = 4000
  // velocidade 4 = 2000
  // velocidade 5 = 1000
  /* ***************************************************************
  * Metodo: stateChanged.
  * Funcao: toda vez que o slider for alterado, vai realizar uma acao correspondente a alteracao.
  * Parametros: ChangeEvent e.
  * Retorno: nenhum.
  *************************************************************** */
  @Override
  public void stateChanged(ChangeEvent e) {

    if(tipo == "pensar"){
      if(slider.getValue()==0){
        jogador.setVelocidadePensar(2000);
        System.out.println("Pensar : 0 ("+jogador.getVelocidadePensar()+")");
      } // fim do if
      if(slider.getValue()==1){
        jogador.setVelocidadePensar(7000);
        System.out.println("Pensar : 1 ("+jogador.getVelocidadePensar()+")");
      } // fim do if
      if(slider.getValue()==2){
        jogador.setVelocidadePensar(5000);
        System.out.println("Pensar : 2 ("+jogador.getVelocidadePensar()+")");
      } // fim do if
      if(slider.getValue()==3){
        jogador.setVelocidadePensar(4000);
        System.out.println("Pensar : 3 ("+jogador.getVelocidadePensar()+")");
      } // fim do if
      if(slider.getValue()==4){
        jogador.setVelocidadePensar(2000);
        System.out.println("Pensar : 4 ("+jogador.getVelocidadePensar()+")");
      } // fim do if 
      if(slider.getValue()==5){
        jogador.setVelocidadePensar(1000);
        System.out.println("Pensar : 5 ("+jogador.getVelocidadePensar()+")");
      } // fim do if
    }else{
      if(slider.getValue()==0){
        jogador.setVelocidadeJogar(1);
        System.out.println("Pensar : 0 ("+jogador.getVelocidadeJogar()+")");
      } // fim do if
      if(slider.getValue()==1){
        jogador.setVelocidadeJogar(7000);
        System.out.println("Pensar : 1 ("+jogador.getVelocidadeJogar()+")");
      } // fim do if
      if(slider.getValue()==2){
        jogador.setVelocidadeJogar(5000);
        System.out.println("Pensar : 2 ("+jogador.getVelocidadeJogar()+")");
      } // fim do if
      if(slider.getValue()==3){
        jogador.setVelocidadeJogar(4000);
        System.out.println("Pensar : 3 ("+jogador.getVelocidadeJogar()+")");
      } // fim do if
      if(slider.getValue()==4){
        jogador.setVelocidadeJogar(2000);
        System.out.println("Pensar : 4 ("+jogador.getVelocidadeJogar()+")");
      } // fim do if 
      if(slider.getValue()==5){
        jogador.setVelocidadeJogar(1000);
        System.out.println("Pensar : 5 ("+jogador.getVelocidadeJogar()+")");
      }
    }
  } // fim do meotod stateChanged
} // fim da class SliderDemo
