

import java.io.IOException;

public class Principal {
  public static void main(String[] args) throws IOException {
    new Mapa();
  } // fim da main
} // fim da class Principal